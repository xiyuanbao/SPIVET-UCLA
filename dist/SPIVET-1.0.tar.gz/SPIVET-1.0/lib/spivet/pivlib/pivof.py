"""
Filename:  pivof.py
Copyright (C) 2007-2010 William Newsome
 
This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details, published at 
http://www.gnu.org/copyleft/gpl.html

/////////////////////////////////////////////////////////////////
Description:
  Module containing optical flow computation routines.

Contents:
  blkflow()
  ofcomp()
  tcfrecon()
"""
import numpy as np
from numpy import *
from scipy import linalg

from pivdata import *
import pivutil
import pivir
from spivet import compat

#import openpiv
import matplotlib.pyplot as plt
import time
from PIL import Image

#################################################################
#
def blkflow(f1,f2,rbndx,pivdict,ip=None):
    """
    ----
    
    f1             # Frame 1 (greyscale mxn array).
    f2             # Frame 2 (greyscale mxn array).
    rbndx          # Block region boundary index (2x2 array).
    pivdict        # Config dictionary.
    ip=None        # Displacement vector to be used as an initial guess.
    
    ----
        
    Computes flow for a given block using a three stage process.  

    Stage I registration is based on the Sequential Similarity Detection 
    Algorithm, and provides a fast registration estimate that has a 
    precision of 1 pixel.  Stage I will only be run if ip = None.
    
    Stage II registration uses normalized cross-correlation for a 
    sub-pixel refinement of Stage I results (or ip if passed).  

    In general, if the Stage II NCC coefficient is below 
    pivdict['of_nccth'], then the frames are registered using irsctxt().
    A sufficiently small NCC coefficient indicates that a good match
    using a correlation type measure could not be found.  Such conditions
    result from: a) excessive particle pattern deformation between frames 
    (eg, in regions of high velocity gradients), or b) the presence of 
    stationary bubbles visible along with moving tracers.  Instead of 
    using a correlation type measure (NCC or SSDA), irsctxt() tries to 
    match every particle in the f1 block to its corresponding particle in 
    the f2 block.  Although the techniques employed in irsctxt() (and 
    other similar approaches) can often produce a reasonable estimate of 
    a displacement vector when correlation type measures fail, use of 
    irsctxt() has two principal drawbacks. First and foremost, irsctxt() 
    results are generally not as accurate as those produced using irncc()
    or irssda().  Nevertheless, when faced with the choice between a 
    completely erroneous displacement vector or a reasonable but somewhat
    inaccurate estimate, blkflow() takes the reasonable estimate path.  
    The second drawback to irsctxt() is the method's computational cost.  
    irsctxt() inner workings are complex and iterative in nature.  As a 
    result, applying irsctxt() to a handful of blocks can consume as much
    computation time as the irssda()/irncc() duo applied to an entire 
    image.  Because of these considerations, the use of irsctxt() is 
    mainly intended to be a lifeline of sorts used only for problematic 
    blocks that fail to register with the primary Stage I and Stage II 
    methods.  Stage III will not be run if irsctxt() is successful.  For 
    more details on the inner workings of irsctxt(), see the irsctxt() 
    documentation.
    
    The pivdict parameter 'of_hrsc' if True will enable irsctxt() to be
    used when ip is set (ie, when ip is not None).  When blkflow() is called by 
    ofcomp(), ip is only set when a block has been subdivided.  Hence, setting
    of_hrsc = True will enable the use of irsctxt() for subdivided blocks.
    
    Stage III registration using the Lucas-Kanade algorithm and the
    registration results from Stage II is run if of_highp is set.  
    If the inac flag is set during Stage III, but was not set with 
    Stage II, then the Stage II results will be kept.

    Returns [p,inac,cmax] where 
        p ----- The computed displacements, p=[dy,dx], in moving 
                from f1 to f2.
        inac -- Inaccuracy flag.  Set > 0 when flow computation fails.
        cmax -- Normalized cross correlation coefficient.  Indicates
                quality of irncc() registration.  Set to -1.0 if
                irsctxt() is called or of_highp is set.
    """

    # Initialization.
    maxdisp   = pivdict['of_maxdisp']
    rmaxdisp  = pivdict['of_rmaxdisp']
    highp     = pivdict['of_highp']
    nccth     = pivdict['of_nccth']
    hrsc     = pivdict['of_hrsc']
    #highp=True
    # Stage 1. 
    haveip = True 
    if ( compat.checkNone(ip) ): 
        [ip,tinac,cmin] = pivir.irssda(f1,f2,rbndx,maxdisp,pivdict)
        haveip = False
	iip=ip;iinac=tinac;icmax=cmin

    pmaxdisp = rmaxdisp
    # Stage 2.
    [ip,tinac,cmax] = pivir.irncc(f1,f2,rbndx,pmaxdisp,pivdict,ip)
    if ( compat.checkNone(ip) ):
        pmaxdisp = maxdisp
    else:
        pmaxdisp = rmaxdisp
    if ( ( cmax < nccth ) and ( hrsc or not haveip ) ):
        [p,inac] = pivir.irsctxt(f1,f2,rbndx,maxdisp,pivdict)
        if ( not compat.checkNone(p) ):
            #return [p,inac,-1.]
	
	    if (haveip == False and 1-icmax/100.>nccth and any(abs(array(iip)-array(p))>array(rmaxdisp)*1.0)):
		return [iip,iinac,1-icmax/100.]
	    else:
		return [p,inac,-1.]
        
    # Stage 3.
    if ( highp ):
        [p,inac] = pivir.irlk(f1,f2,rbndx,pmaxdisp,pivdict,1.,ip)
        if ( ( compat.checkNone(p) ) or ( ( inac > 0 ) and ( tinac == 0 ) ) ):
            if ( not compat.checkNone(ip) ):
                p    = ip
                inac = tinac
            else:
                p = zeros(2,dtype=float)

        return [p,inac,-1.]
    else:
        #return [ip,tinac,cmax]
	
	if (tinac > 0 and haveip == False):
		#print "ssda,icmax=",icmax
		return [iip,iinac,1-icmax/100.]
	else:
		return [ip,tinac,cmax]
	
        
#################################################################
#
#Xiyuan

def ofcomp_gpu(f1,f2,pivdict):
    """
    use openpiv_gpu WIDIM to get displacement
    """
    try:
    	import openpiv.gpu_process
    	import openpiv.process
    	reload(openpiv.gpu_process)
    except:
	print "openpiv not available!"
	raise
    print "STARTING: ofcomp_gpu"

    # Initialization.
    rbndx     = pivdict['gp_rbndx']
    bsize     = pivdict['gp_bsize']
    bolap     = pivdict['gp_bolap']
    bsdiv     = pivdict['gp_bsdiv']
    bsdcmx    = pivdict['of_bsdcmx']

    imdim = f1.shape
    rbndx = array(rbndx)

    [rsize,lbso,hbso,lnblks,hnblks] = pivutil.getblkprm(rbndx,bsize,
                                                        bolap,bsdiv)
    ltnblks = lnblks[0]*lnblks[1]
    f1_c = f1[rbndx[0][0]:rbndx[0][1],rbndx[1][0]:rbndx[1][1]]
    f2_c = f2[rbndx[0][0]:rbndx[0][1],rbndx[1][0]:rbndx[1][1]]

    frame_a = np.round(f1_c*255)
    frame_b = np.round(f2_c*255)
    
    # gpu code parametes
    min_window_size = bsize[0]/bsdiv
    overlap_ratio = float(bolap[0])/bsize[0]
    #min_window_size = 32
    #overlap_ratio = 0.5
    coarse_factor = 1
    nb_iter_max = 2
    dt = 1 # sec
    reload(openpiv.gpu_process)
    try:
    	x, y, u, v, mask = openpiv.gpu_process.WiDIM( frame_a.astype(np.int32), frame_b.astype(np.int32), np.ones(frame_a.shape, dtype=np.int32),
                                                     min_window_size, 
                                                     overlap_ratio,
                                                     coarse_factor,
                                                     dt,
                                                     nb_iter_max = nb_iter_max,
                                                     trust_1st_iter = 0,
                                                     validation_iter = 3)
    except:
	print "Failed GPUPIV. STARTING: ofcomp_Cython"
    	x, y, u, v, mask = openpiv.process.WiDIM( frame_a.astype(np.int32), frame_b.astype(np.int32), np.ones(frame_a.shape, dtype=np.int32),
                                                     min_window_size, 
                                                     overlap_ratio,
                                                     coarse_factor,
                                                     dt,
                                                     nb_iter_max = nb_iter_max,
						     trust_1st_iter = 0,
                                                     validation_iter = 3)
    
    #Xiyuan
    '''
    if x.shape[0]<80:
	path = "/home/xbao/LAB_test/PLUME-3_51V-B25_2-11032008/ANALYSIS/DEBUG/"
	plt.figure(figsize=(f1.shape[1]/50,f1.shape[0]/50))
    	offset=rbndx[0,0]
    	plt.quiver(x[0]+offset,y[::-1,0]+offset,u,v,color='r')
    	plt.imshow(f1,cmap="gray")
	plt.clim(0,1)
	plt.title("Displacement, shape:"+str(frame_a.shape)+\
		" "+str(frame_b.shape))
	plt.savefig(path+str(time.time())+".jpg")
	
	plt.figure(figsize=(f1_c.shape[1]/50,f1_c.shape[0]/50))
	plt.quiver(x[0],y[:,0],u,v,color='b')	
	plt.title("Vector")
	plt.savefig(path+"V_"+str(time.time())+".jpg")

	savetxt(path+"f1_"+str(time.time())+".txt",frame_a,fmt='%.6e')
	savetxt(path+"f2_"+str(time.time())+".txt",frame_b,fmt='%.6e')
		
	im = Image.fromarray(frame_a).convert('L')  
	im.save(path+"f1_"+str(time.time())+".bmp")
	im = Image.fromarray(frame_b).convert('L')       
        im.save(path+"f2_"+str(time.time())+".bmp")
    '''
    hnblks = [x.shape[0],x.shape[1]]
    ofDisp = PIVVar([3,1,hnblks[0],hnblks[1]],'U','PIX')
    ofINAC = PIVVar([1,1,hnblks[0],hnblks[1]],'UINAC','NA',dtype=int)

    ofCMAX = PIVVar([1,1,hnblks[0],hnblks[1]],'CMAX','NA')

    print ' | nyblks %i' % hnblks[0]
    print ' | nxblks %i' % hnblks[1]

    ofDisp[1,0,:,:] = -v
    ofDisp[2,0,:,:] = u
    ofINAC[0,0,:,:] = mask*1#0 means not from interpolated using last iteration
    print " | EXITING: ofcomp_gpu"
    return [ofDisp,ofINAC,ofCMAX]
 
def ofcomp(f1,f2,pivdict):
    """
    ----
    
    f1             # Frame 1 (greyscale mxn array).
    f2             # Frame 2 (greyscale mxn array).
    pivdict        # Config dictionary.
    
    ----
        
    Primary driving routine to compute optical flow between two image
    frames.  Operation proceeds as follows:
        1) ofcomp() subdivides the images into blocks.
        2) Loop start.
        3) Flow for each block is computed using blkflow().
        4) If of_bsdiv > 1 and blkflow() did not return inac for the
           coarse block, the block is subdivided into of_bsdiv sub-blocks
           along each axis.  Flow for each of these sub-blocks is then
           computed, using the results from Step 3 as initialization.
           If blkflow() returns inac for the sub-block, then the flow 
           vector computed from Step 3 will be stored for the sub-block.
           Similarly, if the difference between the normalized cross-correlation
           coefficient from Step 3 and the the subdivided block is greater than 
           of_bsdcmx, then the results of Step 3 will be stored for the 
           sub-block.

    ofcomp() returns [ofDisp, ofINAC, ofCMAX], three PIVVar objects (s,t below 
    are the number of blocks in the y- and x-direction respectively):  
        ofDisp ---- 3 x 1 x s x t PIVVar object containing the displacement
                    vector in moving from f1 to f2.  ofDisp.data[:,:,0] = 0.
                    The variable name will be set to U.
        ofINAC ---- 1 x 1 x s x t PIVVar object containing the inaccuracy flag 
                    (0 indicates a good value, > 0 indicates that the 
                    value should be treated with suspicion).  NOTE: If 
                    of_bsdcmx > 0.0 and of_bsdiv > 1, then INAC will be 
                    negative for cells where coarse results were retained
                    based on of_bsdcmx.  Variable name will be set to UINAC. 
        ofCMAX ---- 1 x 1 x s x t PIVVar object containing the maximum value
                    of the normalized cross-correlation coefficient.  ofCMAX
                    gives a direct measure of the quality of a flow vector with
                    0.0 indicating no match between image frames was found and 
                    1.0 indicating that the computed displacement vector 
                    produced a perfect image match.  ofCMAX will be negative
                    if of_highp is set or irsctxt() has been run.  See
                    blkflow() for more details.  Variable name will be set to
                    CMAX.
    """

    print "STARTING: ofcomp"

    # Initialization.
    rbndx     = pivdict['gp_rbndx']
    bsize     = pivdict['gp_bsize']
    bolap     = pivdict['gp_bolap']
    bsdiv     = pivdict['gp_bsdiv']
    bsdcmx    = pivdict['of_bsdcmx']

    imdim = f1.shape
    rbndx = array(rbndx)

    [rsize,lbso,hbso,lnblks,hnblks] = pivutil.getblkprm(rbndx,bsize,
                                                        bolap,bsdiv)
    #Xiyuan
    print "rsize,lbso,hbso,lnblks,hnblks=",rsize,lbso,hbso,lnblks,hnblks
    print "rbndx,bsize,bolap,bsdiv,bsdcmx=",rbndx,bsize,bolap,bsdiv,bsdcmx
    ltnblks = lnblks[0]*lnblks[1]

    ofDisp = PIVVar([3,1,hnblks[0],hnblks[1]],'U','PIX')
    ofINAC = PIVVar([1,1,hnblks[0],hnblks[1]],'UINAC','NA',dtype=int)
    
    ofCMAX = PIVVar([1,1,hnblks[0],hnblks[1]],'CMAX','NA')

    print ' | nyblks %i' % hnblks[0]
    print ' | nxblks %i' % hnblks[1]

    ofdy   = ofDisp[1,0,:,:]
    ofdx   = ofDisp[2,0,:,:]                
    ofinac = ofINAC[0,0,:,:]

    ofcmax = ofCMAX[0,0,:,:]

    prbndx  = zeros((2,2), dtype=int)
    hprbndx = zeros((2,2), dtype=int)

    # Main loop.
    print " | Flow computation ..."
    tpc = 0
    bn  = 0
    for m in range(lnblks[0]):
        prbndx[0,0] = rbndx[0,0] +m*lbso[0]
        prbndx[0,1] = prbndx[0,0] +bsize[0]
        for n in range(lnblks[1]):
            bn = bn +1

            prbndx[1,0] = rbndx[1,0] +n*lbso[1]
            prbndx[1,1] = prbndx[1,0] +bsize[1]

            # Register the block.
            [p,inac,cmax] = blkflow(f1,f2,prbndx,pivdict)
	    path=""
            if ( bsdiv > 1 ):
                for hm in range(bsdiv):
                    hprbndx[0,0] = prbndx[0,0] +hm*hbso[0]
                    hprbndx[0,1] = hprbndx[0,0] +hbso[0]

                    mndx = m*bsdiv +hm
                    for hn in range(bsdiv):
                        hprbndx[1,0] = prbndx[1,0] +hn*hbso[1]
                        hprbndx[1,1] = hprbndx[1,0] +hbso[1]
                    
                        nndx = n*bsdiv +hn

                        if ( inac == 0 ):
                            [hp,hinac,hcmax] = blkflow(f1,f2,hprbndx,pivdict,p)
                            
                            lowcmx = ( cmax -hcmax ) > bsdcmx     
                            if ( hinac > 0 or lowcmx ):
                                ofdy[mndx, nndx]   = p[0]
                                ofdx[mndx, nndx]   = p[1]
                                if ( lowcmx ):
                                    ofinac[mndx, nndx] = -100. -hinac
				    path = "path1"
                                else:
                                    ofinac[mndx, nndx] = 100. +hinac
                                    path = "path2"
                                ofcmax[mndx, nndx] = cmax
                            else:
                                ofdy[mndx, nndx]   = hp[0]
                                ofdx[mndx, nndx]   = hp[1]
                                ofinac[mndx, nndx] = hinac                            
                                ofcmax[mndx, nndx] = hcmax
				path = "path3"
                        else:
                            ofdy[mndx, nndx]   = p[0]
                            ofdx[mndx, nndx]   = p[1]
                            ofinac[mndx, nndx] = inac
                            ofcmax[mndx, nndx] = cmax
			    path = "path4"
			#if ofinac[mndx, nndx]>0:
                		#print "inaccruate! inac,cmax,path=",ofinac[mndx, nndx],ofcmax[mndx, nndx],path
            else:
                ofdy[m,n]   = p[0]
                ofdx[m,n]   = p[1]
                ofinac[m,n] = inac
                ofcmax[m,n] = cmax
		path = "path5"
            if ( int(10*bn/ltnblks) > tpc ):
                tpc = tpc +1
                print " |  " + str(tpc*10) + "% complete"
    cmax = ofcmax[ofcmax > 0.]
    print " | NCC CMAX MEAN: %f, STDDEV %f" % (cmax.mean(),cmax.std())

    print " | EXITING: ofcomp"
    return [ofDisp,ofINAC,ofCMAX]

#################################################################
#
def tcfrecon(ofDisp0,ofDisp1,pivdict):
    """
    ----
    
    ofDisp0        # PIVVar object with CAM0 flow.
    ofDisp1        # PIVVar object with CAM1 flow.
    pivdict        # Config dictionary.
    
    ----
        
    Reconstructs three component flow using 2D flow fields from
    two seperate cameras (ie, by stereo vision).

    The following geometry is used.  Let dy' and dx', the apparent 
    displacements computed in 2D, be

        dy' = dy +ey                      Eq. 1
        dx' = dx +ex

    where dy and dx are the true displacements, and ey and ex are the
    displacement errors (aka out of plane errors) caused by a non-zero dz.  
    The camera pinhole coordinates in world coordinates are represented 
    as the vector _wcc.  The starting location of the particle at time 
    t=0 will be the vector _xs, with the true final location of the 
    particle given by _xf.  The apparent final location of the particle in
    the xy_world plane will be given by _xf'.  Then,

        yf' = ys +dy'
        xf' = xs +dx'

    Let _r be the vector from (z_w, y_w, x_w) = (0,wcc[1],wcc[2]) to _xf' 
    (_r lies in the xy_world plane).

        r = sqrt( (ys +dy' -wcc[1])^2 +(xs +dx' -wcc[2])^2 )

    Two angles can then be defined such that

        tan(theta) = r/wcc[0]
        sin(phi)   = ys +dy' -wcc[1]
        cos(phi)   = xs +dx' -wcc[2]
    
    The errors due to out of plane displacements can then be represented
    as

        ey = dz*tan(theta)*sin(phi)       # Eq. 2
        ex = dz*tan(theta)*cos(phi)

    Subsituting Eq's 2 into Eq's 1 for each camera yields a set of
    four equations in three unknowns that can be solved by least squares.

    Returns (s,t below are the number of blocks in the y- and x-direction 
    respectively):  
        ofDisp ---- 3 x 1 x s x t PIVVar object containing the three
                    component displacement vector in moving from f1 to f2.
                    Variable name will be set to U3D.  
    """
    # Initialization.
    rbndx   = pivdict['gp_rbndx']
    bsize   = pivdict['gp_bsize']
    bolap   = pivdict['gp_bolap']
    bsdiv   = pivdict['gp_bsdiv']
    camcal0 = pivdict['pg_camcal'][0]
    camcal1 = pivdict['pg_camcal'][1]
    mmpx    = pivdict['pg_wicsp'][0]['mmpx']
    wos     = pivdict['pg_wicsp'][0]['wos']
    high_res= pivdict['high_res']

    nzbolap = ( bolap[0] > 0 ) or ( bolap[1] > 0 )
    if ( ( nzbolap ) and ( bsdiv > 1 ) ):
        print "ERROR: bolap > 0 and bsdiv > 1 cannot be used simultaneously."
        return None

    nyblks = ofDisp0.shape[2]
    nxblks = ofDisp0.shape[3]
    tnblks = nyblks*nxblks

    ofDisp = PIVVar([3,1,nyblks,nxblks],'U3D','MM')

    # Compute coordinates of block centers in world coordinates.
    ndxmat = indices((nyblks,nxblks))
    yv = ndxmat[0,:,:]
    xv = ndxmat[1,:,:]
    if not high_res:
	    absizey = bsize[0]/bsdiv
	    absizex = bsize[1]/bsdiv

	    yv = (yv*(absizey -bolap[0]) +rbndx[0,0] +absizey/2.)*mmpx +wos[0]
	    xv = (xv*(absizex -bolap[1]) +rbndx[1,0] +absizex/2.)*mmpx +wos[1]
    else:
            yv = (yv +rbndx[0,0])*mmpx +wos[0]
            yv = (xv +rbndx[1,0])*mmpx +wos[1]
    yv = yv.reshape(tnblks)
    xv = xv.reshape(tnblks)

    # Compute camera center in world coordinates (wcc) as well as
    # tan(theta)/r, r*cos(phi), and r*sin(phi) for CAM0.
    wcc = linalg.solve(camcal0['Rmat'],-camcal0['T'])

    ofdy0 = mmpx*ofDisp0[1,0,:,:]
    ofdx0 = mmpx*ofDisp0[2,0,:,:]

    ofdy0 = ofdy0.reshape(tnblks)
    ofdx0 = ofdx0.reshape(tnblks)

    ry    = yv +ofdy0 -wcc[1]
    rx    = xv +ofdx0 -wcc[2]
    ttsp0 = ry/wcc[0]
    ttcp0 = rx/wcc[0]

    # Compute camera center in world coordinates (wcc) as well as
    # tan(theta)/r, r*cos(phi), and r*sin(phi) for CAM1.
    wcc = linalg.solve(camcal1['Rmat'],-camcal1['T'])

    ofdy1 = mmpx*ofDisp1[1,0,:,:]
    ofdx1 = mmpx*ofDisp1[2,0,:,:]

    ofdy1 = ofdy1.reshape(tnblks)
    ofdx1 = ofdx1.reshape(tnblks)

    ry    = yv +ofdy1 -wcc[1]
    rx    = xv +ofdx1 -wcc[2]
    ttsp1 = ry/wcc[0]
    ttcp1 = rx/wcc[0]

    # Compute the three components.
    ofdz    = ofDisp[0,0,:,:].reshape(tnblks)
    ofdy    = ofDisp[1,0,:,:].reshape(tnblks)
    ofdx    = ofDisp[2,0,:,:].reshape(tnblks)

    for i in range(tnblks):
        smat      = zeros((4,3),dtype=float)
        smat[0,0] = ttsp0[i]
        smat[0,1] = 1.
        smat[1,0] = ttcp0[i]
        smat[1,2] = 1.
        smat[2,0] = ttsp1[i]
        smat[2,1] = 1.
        smat[3,0] = ttcp1[i]
        smat[3,2] = 1.

        bvec    = zeros(4,dtype=float)
        bvec[0] = ofdy0[i]
        bvec[1] = ofdx0[i]
        bvec[2] = ofdy1[i]
        bvec[3] = ofdx1[i]
    
        smat = matrix(smat)
        bvec = matrix(bvec)
        bvec = array(smat.transpose()*bvec.transpose()).squeeze()
        smat = array(smat.transpose()*smat)

        soln = linalg.solve(smat,bvec)

        ofdz[i] = soln[0]
        ofdy[i] = soln[1]
        ofdx[i] = soln[2]

    return ofDisp
